from django.apps import AppConfig


class AdministratorConfig(AppConfig):
    name = 'administrator'
